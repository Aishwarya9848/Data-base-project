﻿**Players Table Insertion**

INSERT INTO Players (Player\_ID,First\_Name,Last\_Name,Team\_ID)

VALUES (1, 'Virat',’Kohli’, 1 );

INSERT INTO Players (Player\_ID,First\_Name,Last\_Name,Team\_ID)

VALUES (2, 'Rohit',’Sharma’, 1 );

INSERT INTO Players (Player\_ID,First\_Name,Last\_Name,Team\_ID)

VALUES (3, 'Joe',’Root’, 1 );

INSERT INTO Players (Player\_ID,First\_Name,Last\_Name,Team\_ID)

VALUES (4, 'David',’Warner’, 1 );

INSERT INTO Players (Player\_ID,First\_Name,Last\_Name,Team\_ID)

VALUES (5, 'Aaron',’Finch’, 1 );



**Teams Table Insertion**

INSERT INTO Teams(Team\_ID,Team\_Name,Match\_ID,Match\_points)

VALUES (1, 'India',1, 2 );

INSERT INTO Teams(Team\_ID,Team\_Name,Match\_ID,Match\_points)

VALUES (2, ‘Australia',1, 0 );

INSERT INTO Teams(Team\_ID,Team\_Name,Match\_ID,Match\_points)

VALUES (3, 'England',2, 2 );

INSERT INTO Teams(Team\_ID,Team\_Name,Match\_ID,Match\_points)

VALUES (4, 'South Africa',2, 0 );

INSERT INTO Teams(Team\_ID,Team\_Name,Match\_ID,Match\_points)

VALUES (5, 'Bangladesh',3, 1 );


**Matches Table Insertion**

INSERT INTO Matches(Match\_ID,Match\_Name,Match\_Location,Tournament\_ID)

VALUES (1, 'Match1',’Hyderabad’, 1 );

INSERT INTO Matches(Match\_ID,Match\_Name,Match\_Location,Tournament\_ID)

VALUES (2, 'Match2',’Banglore’, 1 );

INSERT INTO Matches(Match\_ID,Match\_Name,Match\_Location,Tournament\_ID)

VALUES (3, 'M3',’Sydney’, 2 );

INSERT INTO Matches(Match\_ID,Match\_Name,Match\_Location,Tournament\_ID)

VALUES (4, 'M4',’Melbourne’, 2 );

INSERT INTO Matches(Match\_ID,Match\_Name,Match\_Location,Tournament\_ID)

VALUES (5, 'Match3',’Mumbai’, 1 );



**Tournamets Table Insertion**

INSERT INTO Tournaments(Tournament\_ID,Tournament\_Name,Tournamnet\_Level,Prize)

VALUES (1, 'World Cup',’Multi Nation’, $800000 );

INSERT INTO Tournaments(Tournament\_ID,Tournament\_Name,Tournamnet\_Level,Prize)

VALUES (2, 'Champions Trophy',’8 teams’, $500000 );



INSERT INTO Tournaments(Tournament_ID,Tournament_Name,Tournamnet_Level,Prize)
VALUES (3, 'Bilateral',’2 teams’, $100000 );

INSERT INTO Tournaments(Tournament_ID,Tournament_Name,Tournamnet_Level,Prize)
VALUES (4, 'Triangular',’3 teams’, $300000 );


INSERT INTO Tournaments(Tournament\_ID,Tournament\_Name,Tournamnet\_Level,Prize)

VALUES (5, 'World Test Championship',’5 teams’, $400000 );


INSERT INTO Tournaments(Tournament\_ID,Tournament\_Name,Tournamnet\_Level,Prize)

VALUES (6, 'Asian cup',’8 teams’, $1000000 );

INSERT INTO Tournaments(Tournament\_ID,Tournament\_Name,Tournamnet\_Level,Prize)

VALUES (7, 'T20 World Cup',’8 teams’, $800000 );





